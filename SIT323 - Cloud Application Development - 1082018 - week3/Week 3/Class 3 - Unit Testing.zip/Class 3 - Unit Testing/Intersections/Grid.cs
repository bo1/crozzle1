﻿using System;

namespace Intersections
{
    public class Grid
    {
        public Char[,] Data { get; set; }
        public int Rows { get; set; }
        public int Columns { get; set; }

        public Grid(String rawGrid)
        {
            rawGrid = rawGrid.Replace("\r\n", "\n");
            String[] rowData = rawGrid.Split(new Char[] { '\n' });

            Rows = rowData.Length;

            Columns = 0;
            foreach (String row in rowData)
                if (row.Length > Columns)
                    Columns = row.Length;

            Data = new Char[Rows + 2, Columns + 2];
            for (int row = 0; row < Rows + 2; row++)
                for (int col = 0; col < Columns + 2; col++)
                    Data[row, col] = ' ';

            int r = 1;
            foreach (String row in rowData)
            {
                int c = 1;
                foreach (Char ch in row)
                    Data[r, c++] = ch;
                r++;
            }


        }

        public String GetIntersections()
        {
            String intersections = "";

            for (int r = 1; r <= Rows; r++)
                for (int c = 1; c <= Columns; c++)
                    if (Data[r, c] != ' ')
                        if((Data[r, c - 1] != ' ' && Data[r - 1, c] != ' ') ||
                           (Data[r, c - 1] != ' ' && Data[r + 1, c] != ' ') ||
                           (Data[r, c + 1] != ' ' && Data[r - 1, c] != ' ') ||
                           (Data[r, c + 1] != ' ' && Data[r + 1, c] != ' '))
                            intersections += Data[r, c];

            return (intersections);
        }

        public String GetRow(int row)
        {
            String data = "";
            
            for (int col = 1; col <= Columns; col++)
                data += Data[row, col];

            return (data);
        }
    }
}
