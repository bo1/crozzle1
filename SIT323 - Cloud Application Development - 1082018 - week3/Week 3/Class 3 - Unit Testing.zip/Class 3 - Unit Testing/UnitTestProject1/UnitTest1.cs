﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Intersections;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            // Arrange test data.
            String testGrid = "APPLE\r\n" +
                              "N  E\r\n" +
                              "TRIAL\r\n" +
                              "   F";

            // Arrange expected results.
            int expectedRows = 4;
            int expectedColumns = 5;
            String expectedRow1 = "APPLE";
            String expectedRow2 = "N  E ";
            String expectedRow3 = "TRIAL";
            String expectedRow4 = "   F ";

            // Act.
            Grid grid = new Grid(testGrid);

            // Assert.
            Assert.AreEqual(expectedRows, grid.Rows, "the number of rows is incorrect");
            Assert.AreEqual(expectedColumns, grid.Columns, "the number of columns is incorrect");
            Assert.AreEqual(expectedRow1, grid.GetRow(1), "row 1 is incorrect");
            Assert.AreEqual(expectedRow2, grid.GetRow(2), "row 2 is incorrect");
            Assert.AreEqual(expectedRow3, grid.GetRow(3), "row 3 is incorrect");
            Assert.AreEqual(expectedRow4, grid.GetRow(4), "row 4 is incorrect");
        }

        [TestMethod]
        public void TestMethod2()
        {
            // Arrange test data.
            String testGrid = "APPLE\r\n" +
                              "N  E\r\n" +
                              "TRIAL\r\n" +
                              "   F";

            // Arrange expected results.
            string expectedIntersections = "ALTA";

            // Act.
            Grid grid = new Grid(testGrid);
            String intersections = grid.GetIntersections();

            // Assert.
            Assert.AreEqual(expectedIntersections, intersections, "GetIntersections() failed");
        }

        [TestMethod]
        public void TestMethod3()
        {
            // Arrange test data.
            String testGrid = "APPLE   PEAR\r\n" +
                              "N  E    A  A\r\n" +
                              "TRIAL   N  I\r\n" +
                              "E  FUN  DAWN\r\n" +
                              "L   N   A\r\n" +
                              "O   A\r\n" +
                              "POLAR\r\n" +
                              "E";

            // Arrange expected results.
            string expectedIntersections = "ALPRTALFUDNPR";

            // Act.
            Grid grid = new Grid(testGrid);
            String intersections = grid.GetIntersections();

            // Assert.
            Assert.AreEqual(expectedIntersections, intersections, "GetIntersections() failed");
        }
    }
}
