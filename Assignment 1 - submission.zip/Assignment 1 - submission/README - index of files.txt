1. Original test documents - see "Assignment 1 - Test Designs.docx"
2. Test files - In project "New Program" - see test project
3. Portfolio documents (test design and test result) - also see "Assignment 1 - Test Designs.docx"
4. Log files - see "log.txt" (note that test 3 doesn't have output to log file as log is not configured in "Test3.cfg")
5. VS solution - in project "New Program" - see main project
6. CFG, CZL and SEQ files - see "Assessment 1 Input Files"
7. Old data files - see "Old Input Files"
